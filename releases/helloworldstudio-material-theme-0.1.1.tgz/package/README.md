# @helloworldstudio/material-theme

Hello World Studio's Material 3 Expressive theme system for React Native, taken from Swipe Rush - Arcade.
One package gives an app a generated color scheme, the M3 type scale in its own fonts, motion and shape
tokens, stored settings, and themed components that take any icon.

Property of Hello World Studio LLC. Use only with the board's permission (see [LICENSE](LICENSE)).

## What's inside

| Part | What it does |
|---|---|
| `ThemeProvider`, `useTheme` | Builds the theme from a seed color and shares it with every component |
| `generateDynamicColors` | Material's own color engine: scheme variants, contrast, the 2025 spec, color-blind modes |
| Fonts | Any font per type scale group or role; system font for the rest |
| `IconProvider`, `Icon` | The app decides what every icon name draws |
| `createSettings` | The app's own settings, typed, loaded at launch and saved on every change |
| Components | Text, Button, IconButton, AnimatedFAB, Switch, SplitButtons, Divider, AvatarText, TouchableRipple, Header, Surface, ExtendedSurface, AnimatedView, ScreenLayout, SettingWidget, Dialog |
| `/gradient` (optional) | `GradientBackground`, a slowly shifting gradient (needs Skia) |
| `/mdi` (optional) | Material Design Icons as the icon fallback |

## Install (local, no remote repository yet)

Releases are packed into `releases/` as `.tgz` files. An app installs one by path, exactly like a
package from npm, and gets its own copy in `node_modules` (no symlinks, so Metro needs no setup).

1. In this folder, make a release:
   ```bash
   npm run release
   ```
   This type-checks the package and writes `releases/helloworldstudio-material-theme-<version>.tgz`.
2. In the app, install it and the libraries it builds on (the app owns these):
   ```bash
   npm install ../material-theme/releases/helloworldstudio-material-theme-0.1.0.tgz
   npm install react-native-reanimated react-native-worklets react-native-safe-area-context
   ```
   Optional: `@shopify/react-native-skia` for `/gradient`, `@react-native-vector-icons/material-design-icons`
   for `/mdi`, and `@react-native-async-storage/async-storage` (or any storage) for settings.
3. The app's `babel.config.js` must include Reanimated's plugin, as Reanimated requires anyway.

### Updating an app

1. Change the code here, add an entry to [CHANGELOG.md](CHANGELOG.md), and raise `version` in
   `package.json` (fix: 0.1.0 → 0.1.1, new feature: → 0.2.0, breaking change: → 0.x+1.0 or 1.0.0).
2. `npm run release`.
3. In each app that should update: `npm install ../material-theme/releases/helloworldstudio-material-theme-<new version>.tgz`.
   Apps that aren't updated keep the version they have.

Later, the same package can move to a private registry (GitHub Packages or a private npm org). Apps then
update with `npm update`, and nothing in the code changes.

## Set up an app

```tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { createSettings, IconProvider, ThemeProvider, type FontOverrides } from '@helloworldstudio/material-theme';
import { materialDesignIcons } from '@helloworldstudio/material-theme/mdi';

// 1. The app's own settings
export const { SettingsProvider, useSettings } = createSettings({
  defaults: { mode: 'light' as 'light' | 'dark', reducedMotion: false, contrast: 'standard' as 'standard' | 'medium' | 'high' },
  storage: AsyncStorage,
  keyPrefix: 'myapp-',
});

// 2. Fonts: by group, by role, or one file per weight. Names are the fonts' PostScript names.
const fonts: FontOverrides = {
  display: 'MyDisplay-Regular',
  headline: 'MyDisplay-Regular',
  body: { regular: 'MySans-Regular', emphasized: 'MySans-Medium' },
  label: { regular: 'MySans-SemiBold', emphasized: 'MySans-Bold' },
};

// 3. Icons: your own, then Material Design Icons for any other name
const icons = {
  logo: ({ size, color }) => <Logo width={size} height={size} fill={color} />,
};

const Themed = ({ children }) => {
  const { settings } = useSettings();
  return (
    <ThemeProvider
      mode={settings.mode}
      colors={{ hue: 270, chroma: 100, tone: 60, variant: 'vibrant', specVersion: '2025', contrast: settings.contrast }}
      fonts={fonts}
      fontScaleCaps={{ display: 1.3, headline: 1.3 }}
      reducedMotion={settings.reducedMotion}
    >
      <IconProvider icons={icons} fallback={materialDesignIcons}>{children}</IconProvider>
    </ThemeProvider>
  );
};

export const Root = () => (
  <SettingsProvider>
    <SafeAreaProvider>
      <Themed><App /></Themed>
    </SafeAreaProvider>
  </SettingsProvider>
);
```

Then, anywhere inside:

```tsx
const { colors, spacing } = useTheme();
<Button mode="contained" icon="logo" emphasized onPress={start}>Start</Button>
<Switch value={settings.reducedMotion} onValueChange={on => update({ reducedMotion: on })} />
```

With React Navigation, pass the theme's `navigation` to it: `<NavigationContainer theme={useTheme().navigation}>`.

### Fonts

- The app adds its font files to its own iOS and Android projects, as React Native requires. The
  package can't ship them.
- `fonts` takes a group (`display`, `headline`, `title`, `body`, `label`) or a role (`titleLarge`). A
  role wins over its group.
- A single name uses the type scale's weights. For static fonts with one file per weight, give
  `{ regular, emphasized }`, so Android never fakes the weight.
- `fontScaleCaps` limits how far each group grows with the phone's text size setting. Wide display fonts
  often need a cap.

### Icons

Every `icon` prop takes:
- a name, looked up in `IconProvider`'s `icons`, then its `fallback`;
- a render function, `({ size, color }) => <MySvg … />`;
- or a ready element, shown as given.

A name nothing knows draws an empty space and warns once in development.

### Settings

- Types come from `defaults`. `update` saves only what changed, and `reset` puts everything back.
- `isReady` is false until the saved values have loaded. Wait for it before showing screens that depend
  on settings.
- Values are stored as JSON, and plain-text values are read back too. So an existing app that stored
  `value.toString()` under the same keys keeps its players' settings when it switches.

## Working on the template

```bash
npm install
npm run typecheck
```

Shared code reaches every app that updates, so for each release:
- note what changed in the changelog;
- raise the version by the right step;
- try it in at least one app before other apps update.
