//Library Imports
import { FC, useEffect } from 'react';
import { StyleSheet, useWindowDimensions } from 'react-native';
import { useTheme } from '../theme/ThemeProvider';

import {
  useSharedValue,
  useDerivedValue,
  withRepeat,
  withTiming,
  interpolateColor,
  cancelAnimation,
} from 'react-native-reanimated';

import {
  Canvas,
  Fill,
  LinearGradient,
  vec,
} from '@shopify/react-native-skia';

//Custom Imports
import type { ColorScheme } from '../theme/types';

type ColorRole = Exclude<keyof ColorScheme, 'elevation'>;

interface GradientBackgroundProps {
  duration?: number; // one sweep across the stops, in ms
  // Three color roles to cycle through, primary's in the middle by default. In dark mode the Vibrant 2025
  // containers stay light, so the dark default uses the deep fixed variants behind on-surface text.
  lightStops?: [ColorRole, ColorRole, ColorRole];
  darkStops?: [ColorRole, ColorRole, ColorRole];
}

/**
 * @fileoverview Optional: a full-screen gradient that slowly shifts between three theme colors.
 * Needs @shopify/react-native-skia installed in the app. Holds still with Reduce Motion.
 *
 * @examples
 * import { GradientBackground } from '@helloworldstudio/material-theme/gradient';
 * <GradientBackground />
 */
export const GradientBackground: FC<GradientBackgroundProps> = ({
  duration = 5000,
  lightStops = ['secondaryContainer', 'primaryContainer', 'tertiaryContainer'],
  darkStops = ['secondaryContainer', 'onPrimaryFixedVariant', 'onTertiaryFixedVariant'],
}) => {
  const { width, height } = useWindowDimensions();
  const { colors, dark, reducedMotion } = useTheme();
  const stops = (dark ? darkStops : lightStops).map(role => colors[role]);

  const progress = useSharedValue(0);

  useEffect(() => {
    if (reducedMotion) {
      cancelAnimation(progress);
      progress.value = 0;
      return;
    }
    progress.value = withRepeat(
      withTiming(1, { duration }),
      -1,
      true
    );

    return () => {
      cancelAnimation(progress);
    };
  }, [duration, progress, reducedMotion]);

  const gradientColors = useDerivedValue(() => {
    return [
      interpolateColor(
        progress.value,
        [0, 0.5, 1],
        [stops[0], stops[1], stops[2]]
      ),

      interpolateColor(
        progress.value,
        [0, 0.5, 1],
        [stops[1], stops[2], stops[0]]
      ),
    ];
  });

  return (
    <Canvas style={StyleSheet.absoluteFill}>
      <Fill>
        <LinearGradient
          start={vec(0, 0)}
          end={vec(width, height)}
          colors={gradientColors}
        />
      </Fill>
    </Canvas>
  );
};