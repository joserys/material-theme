import { FC, ReactNode, useState, useRef, useEffect } from "react";
import { LayoutChangeEvent, View, ViewStyle } from "react-native";
import { useTheme } from '../theme/ThemeProvider';
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useSharedValue, useAnimatedStyle, withTiming, withSpring } from 'react-native-reanimated';
import { Surface } from './surface';
import { scheduleOnRN } from 'react-native-worklets';

export type SlideDirection = 'top' | 'bottom' | 'left' | 'right';

interface ExtendedSurfaceProps {
  children?: ReactNode;
  containerStyle?: ViewStyle; // set `flex` to size the surface from its container instead of its content
  surfaceStyle?: ViewStyle;
  animationDirection?: SlideDirection; // the screen edge it slides in from; it bleeds past that edge
  visible?: boolean;
  onAnimationEnd?: (hidden: boolean) => void; // after it finishes showing (false) or hiding (true)
}

// A level 2 Surface that slides in from a screen edge and extends past it (into the safe area), so it reads
// as coming from off screen. Fades and slides in when `visible`, out when not; jumps with Reduce Motion.
export const ExtendedSurface: FC<ExtendedSurfaceProps> = ({ children, containerStyle = {}, surfaceStyle = {}, animationDirection = 'bottom', visible = true, onAnimationEnd = () => {} }) => {
  //Component State & Setup
  let requiredContainerStyle: ViewStyle = {};
  let requiredSurfaceStyle: ViewStyle = {};

  const { motion, spacing, reducedMotion } = useTheme();
  const { top, bottom, left, right } = useSafeAreaInsets();

  const containerHeight = useRef<number>(0);
  const containerWidth = useRef<number>(0);
  const offScreenTranslation = useRef<number>(0);
  const [dimensionsGathered, setDimensionsGathered] = useState<boolean>(false);

  const surfaceOpacity = useSharedValue<number>(visible ? 1 : 0);
  const translateSurface = useSharedValue<number>(0);

  //Functions
  const updateOffScreenValue = () => {
    if (reducedMotion) {
      offScreenTranslation.current = 0;
    } else {
      switch(animationDirection) {
        case 'bottom':
          offScreenTranslation.current = (containerHeight.current * .25)
          break;
        case 'top':
          offScreenTranslation.current = -(containerHeight.current * .25)
          break;
        case 'left':
          offScreenTranslation.current = -(containerWidth.current * .25)
          break;
        case 'right':
          offScreenTranslation.current = (containerWidth.current * .25)
          break;
      }
    }

    if (!visible || !dimensionsGathered) translateSurface.value = offScreenTranslation.current;
    setDimensionsGathered(true)
  }

  const containerLayout = (event: LayoutChangeEvent) => {
    if (dimensionsGathered) return;
    if (typeof containerStyle.flex === 'undefined') return;
    const { width, height } = event.nativeEvent.layout;
    if (containerWidth.current !== width) containerWidth.current = width;
    if (containerHeight.current !== height) containerHeight.current = height;
    updateOffScreenValue();
  };

  const contentLayout = (event: LayoutChangeEvent) => {
    if (dimensionsGathered) return;
    if (typeof containerStyle.flex !== 'undefined') return;
    const { width, height } = event.nativeEvent.layout;
    if (containerWidth.current !== width) containerWidth.current = width;
    if (containerHeight.current !== height) containerHeight.current = height;
    updateOffScreenValue();
  };

  useEffect(() => {
    if (reducedMotion) {
      if (dimensionsGathered) surfaceOpacity.value = visible ? 1 : 0;
      onAnimationEnd(false);
    } else {
      if (visible && dimensionsGathered) {
        surfaceOpacity.value = withTiming(1, {
          duration: motion.duration.long2, easing: motion.easing.emphasizedDecelerate
        }, (finished) => { if (finished) scheduleOnRN(onAnimationEnd, false) });
        translateSurface.value = withSpring(0, motion.spring.slowSpatial);
      } else {
        surfaceOpacity.value = withTiming(0, {
          duration: motion.duration.medium1, easing: motion.easing.emphasizedAccelerate
        }, (finished) => { if (finished) scheduleOnRN(onAnimationEnd, true)});
        translateSurface.value = withTiming(offScreenTranslation.current, { duration: motion.duration.medium2, easing: motion.easing.emphasizedAccelerate });
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps -- animate only when visibility, layout readiness or the motion setting changes
  }, [visible, dimensionsGathered, reducedMotion]);

  const animationStyle = useAnimatedStyle(() => {
    if (animationDirection === 'bottom' || animationDirection === 'top') {
      return {
        transform: [{ translateY: translateSurface.value }],
        opacity: surfaceOpacity.value,
      };
    } else {
      return {
        transform: [{ translateX: translateSurface.value }],
        opacity: surfaceOpacity.value,
      };
    }
  });

  //On Render
  if (dimensionsGathered) {
    switch(animationDirection) {
      case 'right':
        requiredContainerStyle = {
          width: containerWidth.current + right,
          flexDirection: 'row',
          justifyContent: 'flex-start'
        }

        requiredSurfaceStyle = {
          width: containerWidth.current * 1.25,
          paddingRight: (containerWidth.current * 0.25) - (spacing.large + right)
        }
        break;
      case 'left':
        requiredContainerStyle = {
          width: containerWidth.current + left,
          flexDirection: 'row',
          justifyContent: 'flex-end'
        }

        requiredSurfaceStyle = {
          width: containerWidth.current * 1.25,
          paddingLeft: (containerWidth.current * 0.25) - (spacing.large + left)
        }
        break;
      case 'top':
        requiredContainerStyle = { 
          height: containerHeight.current + top,
          flexDirection: 'column',
          justifyContent: 'flex-end'
        }

        requiredSurfaceStyle = {
          justifyContent: 'flex-end',
          height: (containerHeight.current + top) * 1.25,
          paddingTop: (containerHeight.current * 0.25) - (spacing.large + top)
        }
        break;
      case 'bottom':
        requiredContainerStyle ={
          height: containerHeight.current + bottom,
          flexDirection: 'column',
          justifyContent: 'flex-start'
        }

        requiredSurfaceStyle = {
          justifyContent: 'flex-start',
          height: containerHeight.current * 1.25,
          paddingBottom: (containerHeight.current * 0.25) - (spacing.large + bottom)
        }

        break;
    }
  }

  return (
    <View style={{ ...requiredContainerStyle, ...containerStyle }} onLayout={ containerLayout }>
      <Surface level={ 2 } style={[{ ...requiredSurfaceStyle, ...surfaceStyle }, animationStyle]} onLayout={ contentLayout }>
        { children }
      </Surface>
    </View>
  );
}