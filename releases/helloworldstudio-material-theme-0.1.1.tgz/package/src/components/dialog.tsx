import { FC, ReactNode, useEffect, useState } from 'react';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../theme/ThemeProvider';
import { Icon, IconSource } from '../icons/IconProvider';
import { Button, ButtonMode } from './button';
import { Divider } from './divider';
import { ExtendedSurface } from './extendedSurface';
import { Header } from './header';

export interface DialogAction {
  label: string;
  onPress: () => void;
  icon?: IconSource;
  mode?: ButtonMode;    // default 'contained'
  emphasized?: boolean; // the dialog's main action
  disabled?: boolean;
}

interface DialogProps {
  visible: boolean;
  title: string;
  subTitle?: string;
  icon?: IconSource;
  emphasizeSubTitle?: boolean; // titleLargeEmphasized subtitle, for the moment that matters (e.g. a score)
  actions?: DialogAction[];    // stacked full-width buttons, in order
  children?: ReactNode;
}

// M3 dialog over a dimmed backdrop: icon and title, content, then stacked actions. Slides up when `visible`.
// Buttons stay disabled until it has finished sliding in, and an action runs once it has slid out.
// Render it above the screen's content (it fills its parent).
export const Dialog: FC<DialogProps> = ({ visible, title, subTitle, icon, emphasizeSubTitle = false, actions = [], children }) => {
  const { colors, motion, spacing, size, reducedMotion } = useTheme();
  const { top, bottom, left, right } = useSafeAreaInsets();
  const [shown, setShown] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!visible) {
      setShown(false);
      return;
    }
    // Let the screen behind settle first, as screens change after medium2
    const timer = setTimeout(() => setShown(true), reducedMotion ? 0 : motion.duration.medium2);
    return () => clearTimeout(timer);
  }, [visible, reducedMotion, motion.duration.medium2]);

  const press = (action: DialogAction) => {
    setShown(false);
    setReady(false);
    setTimeout(action.onPress, reducedMotion ? 0 : motion.duration.medium2);
  };

  if (!visible && !shown) return null;

  return (
    <View
      style={{
        backgroundColor: colors.backdrop,
        position: 'absolute', zIndex: 2, top: 0, bottom: 0, right: 0, left: 0,
        paddingTop: top + spacing.xlarge, paddingBottom: bottom + spacing.xlarge,
        paddingRight: right + spacing.xlarge, paddingLeft: left + spacing.xlarge,
      }}
    >
      <ExtendedSurface visible={shown} animationDirection="bottom" onAnimationEnd={hidden => setReady(!hidden)}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          {icon !== undefined && <Icon source={icon} size={size.icon.large} />}
          <Header textAlign="left" style={{ alignItems: 'flex-start', flex: 1, marginLeft: icon !== undefined ? spacing.large : 0 }} title={title} subTitle={subTitle} subTitleVariant={emphasizeSubTitle ? 'titleLargeEmphasized' : undefined} size="small" />
        </View>
        <Divider bold style={{ marginVertical: spacing.largeIncreased }} />
        {children}
        {actions.length > 0 && <Divider bold style={{ marginVertical: spacing.largeIncreased }} />}
        {actions.map((action, index) => (
          <Button
            key={action.label}
            mode={action.mode ?? 'contained'}
            icon={action.icon}
            emphasized={action.emphasized}
            disabled={!ready || action.disabled}
            style={{ marginBottom: index < actions.length - 1 ? spacing.large : 0 }}
            onPress={() => press(action)}
          >
            {action.label}
          </Button>
        ))}
      </ExtendedSurface>
    </View>
  );
};
