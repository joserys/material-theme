import { FC } from 'react';
import { View } from "react-native";
import { useTheme } from '../theme/ThemeProvider';
import { Icon, IconSource } from '../icons/IconProvider';
import { IconButton } from './iconButton';
import { Text } from './text';
import { Divider } from './divider';
import { TouchableRipple } from './touchableRipple';
import { ExtendedSurface, SlideDirection } from './extendedSurface';

interface settingWidgetProps {
  visible?: boolean
  icon?: IconSource
  heading: string
  screenSide: SlideDirection // the side it slides in from
  // Makes the whole card tappable and shows a chevron in the header
  onPress?: () => void
  // With onPress: greys the header, hides the chevron and turns off the press (e.g. while offline)
  disabled?: boolean
  // With onPress: what screen readers announce for the card (defaults to the heading)
  accessibilityLabel?: string
  accessibilityHint?: string
  // Icon button shown at the end of the header (ignored when onPress is set)
  action?: { icon: IconSource, label: string, onPress: () => void }
  children: React.ReactNode
}

export const SettingWidget: FC<settingWidgetProps> = ({
  visible = true,
  icon,
  heading,
  screenSide,
  onPress,
  disabled = false,
  accessibilityLabel,
  accessibilityHint,
  action,
  children
}) => {
  const { spacing, shape, size, state } = useTheme();

  const content = (
    <>
      <View
        style={{
          flex: 1,
          flexDirection: 'row',
          justifyContent: 'flex-start',
          alignItems: 'center',
          opacity: onPress && disabled ? state.disabledContent : 1,
        }}
      >
        {icon !== undefined && <Icon source={icon} size={size.icon.medium} />}
        <Text style={{ flex: 1, marginLeft: icon !== undefined ? spacing.large : 0 }} variant="titleLarge">
          {heading}
        </Text>
        {onPress && !disabled && <Icon source="chevron-right" size={size.icon.medium} />}
        {!onPress && action && (
          <IconButton icon={action.icon} accessibilityLabel={action.label} onPress={action.onPress} style={{ margin: 0 }} />
        )}
      </View>
      <Divider bold style={{ marginVertical: spacing.small }} />
      {children}
    </>
  );

  return (
    <ExtendedSurface
      visible={visible}
      animationDirection={screenSide}
      surfaceStyle={{ marginTop: spacing.xlarge }}
    >
      {content}
      {onPress && (
        // Layered over the whole card (padding included) so the ripple fills it edge to edge, inside a
        // wrapper that clips it to the card's rounded shape (same radius as Surface).
        // Scrolling over the card cancels the press, so a tappable card doesn't get in the way.
        <View style={{ position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, borderRadius: shape.corner.extraLarge, overflow: 'hidden' }}>
          <TouchableRipple
            onPress={onPress}
            disabled={disabled}
            accessibilityLabel={accessibilityLabel ?? heading}
            accessibilityHint={accessibilityHint}
            accessibilityState={{ disabled }}
            style={{ flex: 1 }}
          />
        </View>
      )}
    </ExtendedSurface>
  );
};
