import { FC } from 'react';
import { StyleProp, TextStyle, View, ViewStyle } from 'react-native';
import { Text } from './text';
import { AnimatedView } from './animatedView';
import type { TypescaleVariant } from '../theme/types';

interface HeaderProps {
  title: string;
  subTitle?: string;
  size?: 'large' | 'small';      // large: a screen title (displayLarge over headlineMedium); small: a dialog title (labelSmall over titleLarge)
  titleVariant?: TypescaleVariant;    // overrides the title's type scale role
  subTitleVariant?: TypescaleVariant; // overrides the subtitle's type scale role
  singleLineTitle?: boolean;     // the title never wraps: it shrinks to fit one line instead
  textAlign?: TextStyle['textAlign'];
  flex?: number;
  style?: StyleProp<ViewStyle>;
  visible?: boolean;
  useAnimation?: boolean;        // title slides in from the left, subtitle from the right
}

// A title and subtitle pair: a screen title (large) or a dialog title (small)
export const Header: FC<HeaderProps> = ({
  title,
  subTitle,
  size = 'large',
  titleVariant,
  subTitleVariant,
  singleLineTitle = false,
  textAlign = 'center',
  flex,
  style,
  visible = true,
  useAnimation = false,
}) => {
  const titleRole = titleVariant ?? (size === 'large' ? 'displayLarge' : 'labelSmall');
  const subTitleRole = subTitleVariant ?? (size === 'large' ? 'headlineMedium' : 'titleLarge');
  const titleLineProps = singleLineTitle ? { numberOfLines: 1, adjustsFontSizeToFit: true } : {};

  const titleText = <Text variant={titleRole} style={{ textAlign, width: '100%' }} {...titleLineProps}>{title}</Text>;
  const subTitleText = subTitle ? <Text variant={subTitleRole} style={{ textAlign, width: '100%' }}>{subTitle}</Text> : null;

  return (
    <View style={[{ flex, width: '100%' }, style]}>
      {useAnimation ? (
        <>
          <AnimatedView animationDirection="left" visible={visible}>{titleText}</AnimatedView>
          {subTitleText && <AnimatedView animationDirection="right" visible={visible}>{subTitleText}</AnimatedView>}
        </>
      ) : (
        <>
          {titleText}
          {subTitleText}
        </>
      )}
    </View>
  );
};
