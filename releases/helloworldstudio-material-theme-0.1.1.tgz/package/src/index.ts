/**
 * @helloworldstudio/material-theme
 * Material 3 Expressive theme system for React Native. See README.md for setup.
 */

// Theme
export { ThemeProvider, useTheme } from './theme/ThemeProvider';
export { createMaterialTheme, typescaleGroup } from './theme/createMaterialTheme';
export { generateDynamicColors, DEFAULT_COLOR_OPTIONS } from './theme/colors';
export { withOpacity } from './util/color';
export type * from './theme/types';

// Icons
export { IconProvider, Icon } from './icons/IconProvider';
export type { IconSource, IconRender, IconRenderProps, IconFallback, IconProps } from './icons/IconProvider';

// Settings
export { createSettings } from './settings/createSettings';
export type { SettingsStorage, SettingsOptions, SettingsContextValue, SettingValue } from './settings/createSettings';

// Components
export { Text } from './components/text';
export type { TextProps } from './components/text';
export { Button } from './components/button';
export type { ButtonMode, ButtonProps } from './components/button';
export { IconButton } from './components/iconButton';
export { AnimatedFAB } from './components/animatedFAB';
export type { FABVariant } from './components/animatedFAB';
export { Switch } from './components/switch';
export { SplitButtons } from './components/splitButtons';
export { Divider } from './components/divider';
export { AvatarText } from './components/avatar';
export { TouchableRipple } from './components/touchableRipple';
export type { TouchableRippleProps } from './components/touchableRipple';
export { Header } from './components/header';
export { Surface } from './components/surface';
export { ExtendedSurface } from './components/extendedSurface';
export type { SlideDirection } from './components/extendedSurface';
export { AnimatedView } from './components/animatedView';
export { ScreenLayout } from './components/screenLayout';
export { SettingWidget } from './components/settingWidget';
export { Dialog } from './components/dialog';
export type { DialogAction } from './components/dialog';
