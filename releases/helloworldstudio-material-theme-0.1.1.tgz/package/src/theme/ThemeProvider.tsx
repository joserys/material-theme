import { createContext, FC, ReactNode, useContext, useMemo } from 'react';
import { createMaterialTheme } from './createMaterialTheme';
import type { AppTheme, ThemeOptions } from './types';

const ThemeState = createContext<AppTheme | undefined>(undefined);

interface ThemeProviderProps extends ThemeOptions {
  children: ReactNode;
}

// Builds the app theme with createMaterialTheme and shares it with every component (read it with useTheme).
// Changing `mode` (e.g. from the light/dark setting) or any color option switches the whole app's theme.
// Rebuilt only when an option value changes, so an inline `colors` object is fine; keep `fonts` and
// `fontScaleCaps` stable (define them outside the component).
export const ThemeProvider: FC<ThemeProviderProps> = ({ mode = 'light', colors, fonts, fontScaleCaps, reducedMotion = false, children }) => {
  const { hue, chroma, tone, variant, contrast, specVersion, colorBlindMode } = colors;
  const theme = useMemo(
    () => createMaterialTheme({
      mode,
      colors: { hue, chroma, tone, variant, contrast, specVersion, colorBlindMode },
      fonts,
      fontScaleCaps,
      reducedMotion,
    }),
    [mode, hue, chroma, tone, variant, contrast, specVersion, colorBlindMode, fonts, fontScaleCaps, reducedMotion],
  );
  return <ThemeState.Provider value={theme}>{children}</ThemeState.Provider>;
};

// The current theme (colors, fonts, spacing, shape, motion, elevation, state layers, reducedMotion).
// Must be used inside ThemeProvider.
export const useTheme = (): AppTheme => {
  const theme = useContext(ThemeState);
  if (theme === undefined) throw new Error('useTheme must be used within a ThemeProvider');
  return theme;
};
