/**
 * @fileoverview Stored app settings: a typed provider that loads saved values at launch and saves every change.
 *
 * @description
 * createSettings(options) returns a SettingsProvider and a useSettings hook for one app's own settings type.
 * - defaults: every setting and its default value. Their types (number, boolean, string) are the stored types.
 * - storage: anything with getItem / setItem, e.g. AsyncStorage from @react-native-async-storage/async-storage.
 * - keyPrefix: put before every key in storage (e.g. 'myapp-' stores "myapp-mode").
 *
 * Values are saved as JSON. Values saved as plain text (e.g. "true", "15", "light") are read back too and
 * turned into the default's type, so an app can switch to this from a toString() store without losing data.
 *
 * @examples
 * const { SettingsProvider, useSettings } = createSettings({
 *   defaults: { mode: 'light' as 'light' | 'dark', reducedMotion: false, volume: 1 },
 *   storage: AsyncStorage,
 *   keyPrefix: 'myapp-',
 * });
 * // <SettingsProvider><App /></SettingsProvider>
 * const { settings, update, reset, isReady } = useSettings();
 * update({ mode: 'dark' });
 */

import { createContext, FC, ReactNode, useCallback, useContext, useEffect, useMemo, useReducer, useState } from 'react';

/** The part of a storage library the settings need (AsyncStorage fits as is) */
export interface SettingsStorage {
  getItem: (key: string) => Promise<string | null>;
  setItem: (key: string, value: string) => Promise<void>;
  removeItem?: (key: string) => Promise<void>;
}

export type SettingValue = string | number | boolean | null;

export interface SettingsOptions<T extends Record<string, SettingValue>> {
  defaults: T;
  storage: SettingsStorage;
  keyPrefix?: string;
}

export interface SettingsContextValue<T> {
  settings: T;
  /** Changes some settings and saves them */
  update: (changes: Partial<T>) => void;
  /** Puts every setting back to its default and saves that */
  reset: () => void;
  /** False until the saved values have loaded; until then `settings` holds the defaults */
  isReady: boolean;
}

type Action<T> = { type: 'LOAD' | 'UPDATE'; payload: Partial<T> } | { type: 'RESET' };

// Reads a stored value back as the default's type
const parseStored = (raw: string, fallback: SettingValue): SettingValue => {
  let value: unknown = raw;
  try {
    value = JSON.parse(raw);
  } catch {
    // Saved as plain text, e.g. "light"
  }
  switch (typeof fallback) {
    case 'number': {
      const number = Number(value);
      return Number.isNaN(number) ? fallback : number;
    }
    case 'boolean':
      return typeof value === 'boolean' ? value : String(value).toLowerCase() === 'true';
    case 'string':
      return String(value);
    default:
      return (value as SettingValue) ?? fallback;
  }
};

export const createSettings = <T extends Record<string, SettingValue>>({ defaults, storage, keyPrefix = '' }: SettingsOptions<T>) => {
  const Context = createContext<SettingsContextValue<T> | undefined>(undefined);
  const save = (changes: Partial<T>) => {
    for (const key in changes) {
      storage.setItem(`${keyPrefix}${key}`, JSON.stringify(changes[key])).catch(error => console.warn('[Settings] Could not save:', key, error));
    }
  };

  const reducer = (state: T, action: Action<T>): T => {
    switch (action.type) {
      case 'LOAD':
      case 'UPDATE':
        return { ...state, ...action.payload };
      case 'RESET':
        return { ...defaults };
    }
  };

  const SettingsProvider: FC<{ children: ReactNode }> = ({ children }) => {
    const [settings, dispatch] = useReducer(reducer, defaults);
    const [isReady, setIsReady] = useState(false);

    useEffect(() => {
      let cancelled = false;
      const load = async () => {
        const loaded: Partial<T> = {};
        for (const key in defaults) {
          try {
            const raw = await storage.getItem(`${keyPrefix}${key}`);
            if (raw != null) loaded[key] = parseStored(raw, defaults[key]) as T[typeof key];
          } catch (error) {
            console.warn('[Settings] Could not load:', key, error);
          }
        }
        if (cancelled) return;
        dispatch({ type: 'LOAD', payload: loaded });
        setIsReady(true);
      };
      load();
      return () => { cancelled = true; };
    }, []);

    const update = useCallback((changes: Partial<T>) => {
      save(changes);
      dispatch({ type: 'UPDATE', payload: changes });
    }, []);
    const reset = useCallback(() => {
      save(defaults);
      dispatch({ type: 'RESET' });
    }, []);

    // Same object until a setting changes, so consumers don't re-render for nothing
    const value = useMemo(() => ({ settings, update, reset, isReady }), [settings, update, reset, isReady]);
    return <Context.Provider value={value}>{children}</Context.Provider>;
  };

  const useSettings = (): SettingsContextValue<T> => {
    const value = useContext(Context);
    if (value === undefined) throw new Error('useSettings must be used within its SettingsProvider');
    return value;
  };

  return { SettingsProvider, useSettings };
};
