# Changelog

Version numbers say how safe an update is: `0.1.0 → 0.1.1` is a fix, `→ 0.2.0` adds features, and
`→ 1.0.0` or any `0.x` minor step can change how existing code works. Read the entry before updating.

## 0.1.0 — 2026-11-04

First version, taken from Swipe Rush - Arcade.

- Theme: `ThemeProvider`, `useTheme`, `createMaterialTheme`. Material 3 Expressive colors from a seed
  (`generateDynamicColors`: scheme variants, contrast, the 2025 spec, color-blind modes), the type scale
  with emphasized weights, spacing, shape, motion, elevation, state layers, and a `navigation` theme.
- Fonts: any font per type scale group or role (`fonts`), and optional text size caps per group
  (`fontScaleCaps`). No fonts are built in; anything left out uses the system font.
- Reduce Motion: the app's own setting, passed to `ThemeProvider` as `reducedMotion`.
- Icons: `IconProvider` and `Icon`. Every component takes an icon name, a render function or an element.
  Material Design Icons is optional (`/mdi`).
- Settings: `createSettings` for an app's own typed settings, saved to any storage (e.g. AsyncStorage).
- Components: Text, Button, IconButton, AnimatedFAB, Switch, SplitButtons, Divider, AvatarText,
  TouchableRipple, Header, Surface, ExtendedSurface, AnimatedView, ScreenLayout, SettingWidget, Dialog.
- Optional: `GradientBackground` (`/gradient`, needs Skia).
