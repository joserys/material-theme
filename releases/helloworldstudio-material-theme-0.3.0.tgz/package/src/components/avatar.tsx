import { FC } from 'react';
import { StyleProp, Text as NativeText, View, ViewStyle } from 'react-native';
import { useTheme } from '../theme/ThemeProvider';

interface AvatarTextProps {
  label: string;          // usually 1-2 initials
  size?: number;
  color?: string;         // defaults to onPrimary
  backgroundColor?: string; // defaults to primary
  style?: StyleProp<ViewStyle>;
}

// Round avatar showing initials, used when there's no profile picture
export const AvatarText: FC<AvatarTextProps> = ({ label, size = 64, color, backgroundColor, style }) => {
  const { colors, fonts } = useTheme();
  return (
    <View
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      style={[{ width: size, height: size, borderRadius: size / 2, backgroundColor: backgroundColor ?? colors.primary, alignItems: 'center', justifyContent: 'center' }, style]}
    >
      <NativeText
        numberOfLines={1}
        style={{ fontFamily: fonts.titleMedium.fontFamily, fontWeight: fonts.titleMedium.fontWeight, fontSize: size / 2.5, color: color ?? colors.onPrimary }}
      >
        {label}
      </NativeText>
    </View>
  );
};
