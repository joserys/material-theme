import { FC, useEffect, useState } from 'react';
import { StyleProp, TextInput, TextInputProps, View, ViewStyle } from 'react-native';
import Animated, { interpolate, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { useTheme } from '../theme/ThemeProvider';
import { withOpacity } from '../util/color';
import { Icon, IconSource } from '../icons/IconProvider';
import { IconButton } from './iconButton';
import { Text } from './text';

export interface TextFieldProps extends Omit<TextInputProps, 'style' | 'placeholderTextColor' | 'editable'> {
  label: string;
  mode?: 'filled' | 'outlined';  // default 'filled'
  supportingText?: string;       // helper text under the field
  error?: boolean;
  errorText?: string;            // shown instead of supportingText while `error`
  leadingIcon?: IconSource;
  trailingIcon?: IconSource;     // e.g. clear or show password
  onTrailingIconPress?: () => void;
  trailingIconAccessibilityLabel?: string;
  disabled?: boolean;
  /** Outlined fields: the color behind the field, so the floating label's cut-out matches. Default surface. */
  backgroundColor?: string;
  style?: StyleProp<ViewStyle>;
}

const HEIGHT = 56;
const LABEL_SCALE = 12 / 16; // bodyLarge label shrinks to bodySmall

// M3 text field, filled or outlined, 56dp tall. The label sits in the field (bodyLarge) and floats up
// (bodySmall) when focused or filled. Filled: surfaceContainerHighest with 4dp top corners and an
// indicator line (1dp, 2dp primary when focused). Outlined: 4dp corners, 1dp outline, 2dp primary when
// focused, with the label cut into the outline. Supporting or error text below in bodySmall.
export const TextField: FC<TextFieldProps> = ({
  label, mode = 'filled', supportingText, error = false, errorText, leadingIcon, trailingIcon, onTrailingIconPress,
  trailingIconAccessibilityLabel, disabled = false, backgroundColor, style, value, defaultValue, onFocus, onBlur, onChangeText,
  ...inputProps
}) => {
  const { colors, fonts, shape, spacing, size, state, motion, reducedMotion, fontScaleCaps } = useTheme();
  const [focused, setFocused] = useState(false);
  const [text, setText] = useState(defaultValue ?? '');
  const shown = value ?? text;
  const floated = focused || shown.length > 0;
  const float = useSharedValue(floated ? 1 : 0);

  useEffect(() => {
    float.value = reducedMotion ? (floated ? 1 : 0) : withTiming(floated ? 1 : 0, { duration: motion.duration.short4, easing: motion.easing.standard });
  }, [floated, reducedMotion, float, motion]);

  const filled = mode === 'filled';
  const disabledContent = withOpacity(colors.onSurface, state.disabledContent);
  const accent = disabled ? disabledContent : error ? colors.error : focused ? colors.primary : null;
  const labelColor = accent ?? colors.onSurfaceVariant;
  const lineColor = accent ?? (filled ? colors.onSurfaceVariant : colors.outline);
  const lineWidth = focused && !disabled ? 2 : 1;
  const iconColor = disabled ? disabledContent : colors.onSurfaceVariant;
  const startInset = leadingIcon !== undefined ? 52 : spacing.large;

  // Label: resting in the middle of the field; floated near the top (filled) or onto the outline (outlined)
  const restingTop = (HEIGHT - fonts.bodyLarge.lineHeight) / 2;
  const floatedTop = filled ? spacing.med : -fonts.bodyLarge.lineHeight / 2;
  const labelStyle = useAnimatedStyle(() => ({
    top: interpolate(float.value, [0, 1], [restingTop, floatedTop]),
    transform: [{ scale: interpolate(float.value, [0, 1], [1, LABEL_SCALE]) }],
  }));
  const message = error && errorText ? errorText : supportingText;

  return (
    <View style={style}>
      <View
        style={{
          height: HEIGHT,
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: filled ? (disabled ? withOpacity(colors.onSurface, 0.04) : colors.surfaceContainerHighest) : 'transparent',
          borderTopLeftRadius: shape.corner.extraSmall,
          borderTopRightRadius: shape.corner.extraSmall,
          borderBottomLeftRadius: filled ? 0 : shape.corner.extraSmall,
          borderBottomRightRadius: filled ? 0 : shape.corner.extraSmall,
          ...(filled ? { borderBottomWidth: lineWidth, borderColor: lineColor } : { borderWidth: lineWidth, borderColor: lineColor }),
        }}
      >
        {leadingIcon !== undefined && <Icon source={leadingIcon} size={size.icon.medium} color={iconColor} style={{ marginLeft: spacing.medLarge }} />}
        <TextInput
          {...inputProps}
          value={value}
          defaultValue={defaultValue}
          editable={!disabled}
          accessibilityLabel={inputProps.accessibilityLabel ?? label}
          accessibilityState={{ disabled }}
          maxFontSizeMultiplier={fontScaleCaps.body}
          onChangeText={next => { setText(next); onChangeText?.(next); }}
          onFocus={event => { setFocused(true); onFocus?.(event); }}
          onBlur={event => { setFocused(false); onBlur?.(event); }}
          placeholder={floated ? inputProps.placeholder : undefined}
          placeholderTextColor={colors.onSurfaceVariant}
          cursorColor={error ? colors.error : colors.primary}
          selectionColor={withOpacity(error ? colors.error : colors.primary, 0.4)}
          style={[fonts.bodyLarge, {
            flex: 1,
            height: '100%',
            color: disabled ? disabledContent : colors.onSurface,
            paddingLeft: leadingIcon !== undefined ? spacing.medLarge : spacing.large,
            paddingRight: trailingIcon !== undefined ? 0 : spacing.large,
            paddingTop: filled ? spacing.largeIncreased + spacing.small : 0,
            paddingBottom: filled ? spacing.med : 0,
          }]}
        />
        {trailingIcon !== undefined && (
          <IconButton icon={trailingIcon} iconColor={error && !disabled ? colors.error : iconColor} onPress={onTrailingIconPress} disabled={disabled} accessibilityLabel={trailingIconAccessibilityLabel} style={{ marginHorizontal: spacing.small }} />
        )}
        <Animated.View
          pointerEvents="none"
          style={[{
            position: 'absolute',
            left: startInset - (filled ? 0 : spacing.small),
            transformOrigin: 'left center',
            paddingHorizontal: filled ? 0 : spacing.small,
            backgroundColor: filled ? 'transparent' : floated ? backgroundColor ?? colors.surface : 'transparent',
          }, labelStyle]}
        >
          <Text variant="bodyLarge" numberOfLines={1} accessible={false} style={{ color: labelColor }}>{label}</Text>
        </Animated.View>
      </View>
      {message !== undefined && (
        <Text variant="bodySmall" style={{ color: error && !disabled ? colors.error : iconColor, marginTop: spacing.small, paddingHorizontal: spacing.large }}>{message}</Text>
      )}
    </View>
  );
};
